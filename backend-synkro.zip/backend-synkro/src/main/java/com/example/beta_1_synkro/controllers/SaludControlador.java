package com.example.beta_1_synkro.controllers;

import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

// Endpoint de salud: sirve para comprobar rápido que el backend está encendido.
//   http://localhost:8080/api/salud
@RestController
public class SaludControlador {

    @GetMapping("/api/salud")
    public Map<String, Object> salud() {
        Map<String, Object> respuesta = new LinkedHashMap<>();
        respuesta.put("estado", "ok");
        respuesta.put("proyecto", "beta_1_synkro");
        respuesta.put("mensaje", "El backend esta funcionando correctamente");
        return respuesta;
    }
}

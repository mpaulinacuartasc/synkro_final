package com.example.beta_1_synkro.config;

import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

// Convierte los errores de la base de datos en mensajes entendibles para el frontend.
// Sin esto, el frontend solo recibe "Internal Server Error" y no se sabe qué pasó.
@RestControllerAdvice
public class ManejadorErrores {

    @ExceptionHandler(DataIntegrityViolationException.class)
    public ResponseEntity<Map<String, Object>> datosDuplicados(DataIntegrityViolationException e) {
        Map<String, Object> cuerpo = new LinkedHashMap<>();
        cuerpo.put("error", "Datos duplicados o incompletos");
        cuerpo.put("message", "Ya existe un registro con ese NIT, correo o teléfono, "
                + "o falta un campo obligatorio. Revisa los datos e intenta de nuevo.");
        cuerpo.put("status", 409);
        return ResponseEntity.status(HttpStatus.CONFLICT).body(cuerpo);
    }
}

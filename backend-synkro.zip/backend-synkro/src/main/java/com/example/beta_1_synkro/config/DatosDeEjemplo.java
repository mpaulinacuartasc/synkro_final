package com.example.beta_1_synkro.config;

import java.time.LocalDate;
import java.time.LocalDateTime;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.example.beta_1_synkro.models.Categoria;
import com.example.beta_1_synkro.models.Empresa;
import com.example.beta_1_synkro.models.Prioridad;
import com.example.beta_1_synkro.models.Registro;
import com.example.beta_1_synkro.models.Reto;
import com.example.beta_1_synkro.repository.IRepositorioEmpresa;
import com.example.beta_1_synkro.repository.IRepositorioPrioridad;
import com.example.beta_1_synkro.repository.IRepositorioRegistro;
import com.example.beta_1_synkro.repository.IRepositorioReto;
import com.example.beta_1_synkro.repository.IrepositorioCategoria;

// Carga unos datos de ejemplo la primera vez que arranca el backend, para que el
// frontend no aparezca vacio. Como H2 es una base en memoria, estos datos se
// vuelven a crear en cada arranque.
//
// Si NO quieres datos de ejemplo, comenta la anotacion @Configuration.
@Configuration
public class DatosDeEjemplo {

    @Bean
    CommandLineRunner cargarDatos(IRepositorioEmpresa empresas,
                                  IrepositorioCategoria categorias,
                                  IRepositorioPrioridad prioridades,
                                  IRepositorioReto retos,
                                  IRepositorioRegistro registros) {
        return args -> {
            if (empresas.count() > 0) {
                return; // ya hay datos, no se duplican
            }

            Empresa empresa = new Empresa();
            empresa.setNombre("Innova S.A.S.");
            empresa.setNit("900123456-7");
            empresa.setSector("Tecnologia");
            empresa.setContacto("Ana Gomez");
            empresa.setCorreo("contacto@innova.com");
            empresa.setTelefono("3001234567");
            empresa.setActiva(true);
            empresas.save(empresa);

            Categoria categoria = new Categoria();
            categoria.setNombre("Innovacion");
            categoria.setCategoria("Innovacion abierta");
            categoria.setDescripcion("Retos de innovacion empresarial");
            categorias.save(categoria);

            Prioridad prioridad = new Prioridad();
            prioridad.setNombre("Alta");
            prioridad.setNivel(1);
            prioridades.save(prioridad);

            Reto reto = new Reto();
            reto.setNombre("Digitalizar el proceso de pedidos");
            reto.setDescripcion("Pasar el registro manual de pedidos a un formulario en linea");
            reto.setFecha_inicio(LocalDate.now());
            reto.setFecha_fin(LocalDate.now().plusMonths(2));
            reto.setEstado("abierto");
            retos.save(reto);

            Registro registro = new Registro();
            registro.setFechaRegistro(LocalDateTime.now());
            registro.setObservacion("Se definio el alcance inicial del reto");
            registro.setEstado("pendiente");
            registros.save(registro);
        };
    }
}

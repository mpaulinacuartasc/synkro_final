# Cómo encender el backend (Synkro)

## 1. Requisito
Necesitas **Java 17** o superior. Compruébalo abriendo una terminal:

```
java -version
```

Debe decir `17` o un número mayor. Si dice 11 o 8, no va a funcionar.

## 2. Encender
Entra a esta carpeta (donde está `pom.xml`) y ejecuta:

**Windows:**
```
mvnw spring-boot:run
```
**Mac / Linux:**
```
./mvnw spring-boot:run
```

> En Windows PowerShell a veces hay que escribir `.\mvnw spring-boot:run`

La primera vez tarda 1-2 minutos porque descarga dependencias. Al final aparece:

```
Started Beta1SynkroApplication in X seconds
```

**Deja esa terminal abierta.** Si la cierras, el backend se apaga.

## 3. Comprobar que está vivo
Abre el navegador en:

```
http://localhost:8080/api/salud
```

Debe aparecer: `{"estado":"ok", ...}`

## 4. Rutas disponibles

| Recurso | Ruta |
|---|---|
| Empresas | `http://localhost:8080/api/empresas` |
| Categorías | `http://localhost:8080/api/categorias` |
| Prioridades | `http://localhost:8080/api/prioridades` |
| Retos | `http://localhost:8080/api/retos` |
| Registros | `http://localhost:8080/api/registros` |
| Salud | `http://localhost:8080/api/salud` |

## Datos de ejemplo
Al arrancar, el backend crea 1 empresa, 1 categoría, 1 prioridad, 1 reto y 1 registro para que el frontend no salga vacío.

Como la base de datos H2 es **en memoria**, todo lo que crees se borra al apagar el backend.
Si quieres que arranque vacío, abre `src/main/java/com/example/beta_1_synkro/config/DatosDeEjemplo.java` y comenta la línea `@Configuration`.

# Cómo encender el frontend

## 1. Requisito
Necesitas **Node.js 18 o superior**. Compruébalo:

```
node -v
```

Debe decir `v18`, `v20` o mayor. Si dice `v16`, actualízalo desde https://nodejs.org

## 2. Instalar (solo la primera vez)
Abre una terminal **dentro de esta carpeta** y ejecuta:

```
npm install
```

Tarda un minuto y crea la carpeta `node_modules`.

## 3. Encender

```
npm run dev
```

Aparece una línea así:

```
  ➜  Local:   http://localhost:5173/
```

Abre esa dirección en el navegador. **Deja esta terminal abierta.**

## 4. Orden importante
1. Primero enciende el **backend** (otra terminal).
2. Después enciende el **frontend**.

Si el frontend dice "No fue posible conectar", es que el backend está apagado.

## ¿Dónde se cambia la dirección del backend?
En un solo archivo: `src/config/miApi.js`, en la línea `URL_BASE`.
También puedes escribir otra URL en la barra superior de la página, sin tocar código.

## Estructura
```
src/
├── config/miApi.js        ← URL, rutas y campos de los formularios (aquí se toca)
├── services/              ← las llamadas a la API con fetch
├── pages/                 ← una página por recurso
├── components/commons/    ← tabla, formulario, modal, botones...
└── hooks/                 ← lógica de CRUD y de formularios
```

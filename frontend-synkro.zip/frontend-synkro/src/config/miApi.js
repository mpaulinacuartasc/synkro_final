// =============================================================================
// CONFIGURACIÓN DE MI API (Synkro · Grupo 1)
// -----------------------------------------------------------------------------
// Conexión del frontend con el backend Spring Boot. Todo está centralizado
// aquí para que si cambias de puerto solo toques este archivo.
//
// Backend: Java 17 + Spring Boot, puerto 8080, base de datos H2 en memoria.
// =============================================================================

// Dirección del backend. Se puede sobrescribir con la variable VITE_API_URL
// de un archivo .env, pero por defecto usa localhost:8080.
export const URL_BASE = import.meta.env.VITE_API_URL || 'http://localhost:8080';

// Rutas que exponen los @RequestMapping de los controladores del backend
export const RUTAS = {
  empresas: '/api/empresas',
  categorias: '/api/categorias',
  prioridades: '/api/prioridades',
  retos: '/api/retos',
  registros: '/api/registros',
};

// ---- Campos de cada formulario -------------------------------------------------
// Deben coincidir EXACTAMENTE con los atributos de los modelos de Java:
//   Empresa     -> nombre, nit, sector, contacto, correo, telefono, activa
//   Categoria   -> nombre, categoria, descripcion
//   Prioridad   -> nombre, nivel
//   Reto        -> nombre, descripcion, fecha_inicio, fecha_fin, estado
//   Registro    -> fechaRegistro, observacion, estado
// -----------------------------------------------------------------------------

export const ESTADOS_RETO = ['abierto', 'en progreso', 'cerrado'];
export const ESTADOS_REGISTRO = ['pendiente', 'revisado', 'aprobado'];

export const CAMPOS = {
  empresas: [
    { nombre: 'nombre', etiqueta: 'Nombre', tipo: 'texto', requerido: true, max: 50, placeholder: 'Ej: Innova S.A.S.' },
    { nombre: 'nit', etiqueta: 'NIT', tipo: 'texto', requerido: true, max: 20, placeholder: 'Ej: 900123456-7' },
    { nombre: 'sector', etiqueta: 'Sector', tipo: 'texto', requerido: true, max: 30, placeholder: 'Ej: Tecnología' },
    { nombre: 'contacto', etiqueta: 'Persona de contacto', tipo: 'texto', requerido: true, max: 50, placeholder: 'Ej: Ana Gómez' },
    { nombre: 'correo', etiqueta: 'Correo', tipo: 'email', requerido: true, max: 80, placeholder: 'contacto@empresa.com' },
    { nombre: 'telefono', etiqueta: 'Teléfono', tipo: 'telefono', requerido: true, max: 10, placeholder: '3001234567' },
    { nombre: 'activa', etiqueta: 'Empresa activa', tipo: 'booleano', valorInicial: true },
  ],
  categorias: [
    { nombre: 'nombre', etiqueta: 'Nombre', tipo: 'texto', requerido: true, max: 50, placeholder: 'Ej: Innovación' },
    { nombre: 'categoria', etiqueta: 'Categoría', tipo: 'texto', requerido: true, max: 80, placeholder: 'Ej: Innovación abierta' },
    { nombre: 'descripcion', etiqueta: 'Descripción', tipo: 'textoLargo', requerido: true, max: 100 },
  ],
  prioridades: [
    { nombre: 'nombre', etiqueta: 'Nombre', tipo: 'texto', requerido: true, max: 50, placeholder: 'Ej: Alta' },
    { nombre: 'nivel', etiqueta: 'Nivel', tipo: 'numero', requerido: true, min: 1, max: 10, placeholder: '1 = más urgente' },
  ],
  retos: [
    { nombre: 'nombre', etiqueta: 'Nombre del reto', tipo: 'texto', requerido: true, max: 50 },
    { nombre: 'descripcion', etiqueta: 'Descripción', tipo: 'textoLargo', requerido: true, max: 400 },
    { nombre: 'fecha_inicio', etiqueta: 'Fecha de inicio', tipo: 'fecha', requerido: true },
    { nombre: 'fecha_fin', etiqueta: 'Fecha de fin', tipo: 'fecha', requerido: true },
    { nombre: 'estado', etiqueta: 'Estado', tipo: 'seleccion', opciones: ESTADOS_RETO, requerido: true },
  ],
  registros: [
    { nombre: 'fechaRegistro', etiqueta: 'Fecha del registro', tipo: 'fechaHora', requerido: true },
    { nombre: 'observacion', etiqueta: 'Observación', tipo: 'textoLargo', requerido: true, max: 200 },
    { nombre: 'estado', etiqueta: 'Estado', tipo: 'seleccion', opciones: ESTADOS_REGISTRO, requerido: true },
  ],
};

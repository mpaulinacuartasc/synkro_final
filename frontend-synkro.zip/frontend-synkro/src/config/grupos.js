// =============================================================================
// CONFIGURACIÓN DE LA API CON LA QUE TRABAJA ESTE FRONTEND
// -----------------------------------------------------------------------------
// Este frontend está conectado al backend del Grupo 1 · Synkro.
// Los datos de conexión (URL y rutas) y los campos de los formularios están en
// src/config/miApi.js, que es el ÚNICO archivo que necesitas tocar si cambias
// de puerto o de backend.
// =============================================================================

import { URL_BASE, RUTAS, CAMPOS } from './miApi';

export const GRUPOS = [
  {
    id: '1',
    nombre: 'Grupo 1 · Synkro',
    proyecto: 'beta_1_synkro',
    rutas: RUTAS,
    campos: CAMPOS,
  },
];

export const GRUPO_POR_DEFECTO = GRUPOS[0];

export const buscarGrupo = (id) => GRUPOS.find((g) => g.id === id) ?? GRUPO_POR_DEFECTO;

export { URL_BASE };

// Muestra a qué backend está conectado el frontend (Grupo 1 · Synkro).
// Si el backend se levanta en otro puerto, aquí se puede escribir la nueva URL.

import { useEffect, useState } from 'react';
import { useGrupo } from '../../context/GrupoContext';
import Icono from './Icono';

export default function SelectorGrupo() {
  const { grupo, urlBase, cambiarUrlBase } = useGrupo();
  const [url, setUrl] = useState(urlBase);

  // Si la URL cambia desde fuera, se sincroniza el input
  useEffect(() => {
    setUrl(urlBase);
  }, [urlBase]);

  const aplicarUrl = () => {
    const limpia = url.trim();
    if (limpia && limpia !== urlBase) cambiarUrlBase(limpia);
  };

  return (
    <div className="selector-grupo">
      <span className="selector-grupo__campo">
        <Icono nombre="servidor" tamano={15} />
        <span title={grupo.proyecto}>{grupo.nombre}</span>
      </span>
      <label className="selector-grupo__campo selector-grupo__url">
        <Icono nombre="servidor" tamano={15} />
        <input
          value={url}
          onChange={(e) => setUrl(e.target.value)}
          onBlur={aplicarUrl}
          onKeyDown={(e) => e.key === 'Enter' && aplicarUrl()}
          aria-label="URL del backend"
          title="URL del backend Spring Boot"
          spellCheck={false}
        />
      </label>
    </div>
  );
}
